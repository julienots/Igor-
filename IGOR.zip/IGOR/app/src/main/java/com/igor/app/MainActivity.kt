package com.igor.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

/**
 * IGOR embarque son application web (assets/igor.html, autonome et déjà fonctionnelle
 * dans n'importe quel navigateur) dans une simple WebView. Cette activité ajoute
 * uniquement ce qu'un navigateur mobile normal offrirait déjà :
 * - le stockage local (localStorage) persistant pour garder la configuration et
 *   l'historique,
 * - le sélecteur de fichiers natif pour la pièce jointe (📎),
 * - l'enregistrement réel des fichiers "téléchargés" (réponse .md, blocs de code)
 *   dans le dossier Téléchargements du téléphone plutôt qu'un blob invisible.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var fileChooserLauncher: ActivityResultLauncher<Intent>
    private var pendingDownload: Pair<String, String>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        fileChooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = filePathCallback
            filePathCallback = null
            if (cb == null) return@registerForActivityResult
            val data = result.data
            if (result.resultCode != Activity.RESULT_OK || data == null) {
                cb.onReceiveValue(null)
                return@registerForActivityResult
            }
            val uris = if (data.clipData != null) {
                val clip = data.clipData!!
                Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
            } else {
                val single = data.data
                if (single != null) arrayOf(single) else arrayOf()
            }
            cb.onReceiveValue(uris)
        }

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.setSupportZoom(false)
        settings.textZoom = 100

        webView.addJavascriptInterface(DownloadBridge(), "AndroidDownloader")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                // La page locale et ses sous-ressources restent dans la WebView ;
                // tout lien externe (http/https vers un autre domaine que les CDN
                // déjà chargés, ex. clic sur un lien dans une réponse d'IA) s'ouvre
                // dans le navigateur du téléphone.
                if (url.scheme == "file") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                    true
                } catch (e: Exception) {
                    false
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                // Redirige les téléchargements (réponse .md, blocs de code) vers le
                // pont natif plutôt que vers un blob invisible en WebView.
                view.evaluateJavascript(
                    """
                    (function(){
                        window.downloadText = function(text, filename){
                            if (window.AndroidDownloader) {
                                AndroidDownloader.save(filename, text);
                            } else {
                                var blob = new Blob([text], {type:'text/plain'});
                                var url = URL.createObjectURL(blob);
                                var a = document.createElement('a');
                                a.href = url; a.download = filename;
                                document.body.appendChild(a); a.click(); a.remove();
                                URL.revokeObjectURL(url);
                            }
                        };
                    })();
                    """.trimIndent(),
                    null
                )
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                return try {
                    fileChooserLauncher.launch(Intent.createChooser(intent, "Choisir un fichier"))
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                // Igor n'a besoin ni de la caméra ni du micro ; on refuse par défaut.
                request.deny()
            }
        }

        webView.loadUrl("file:///android_asset/igor.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    /** Pont JS -> Kotlin utilisé pour enregistrer réellement les fichiers générés par Igor. */
    inner class DownloadBridge {
        @JavascriptInterface
        fun save(filename: String, content: String) {
            runOnUiThread {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                    ContextCompat.checkSelfPermission(this@MainActivity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                ) {
                    pendingDownload = filename to content
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),
                        42
                    )
                } else {
                    writeDownload(filename, content)
                }
            }
        }
    }

    private fun writeDownload(filename: String, content: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    toast("Enregistré dans Téléchargements : $filename")
                } else {
                    toast("Échec de l'enregistrement")
                }
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, filename)
                FileOutputStream(file).use { it.write(content.toByteArray()) }
                toast("Enregistré dans Téléchargements : $filename")
            }
        } catch (e: Exception) {
            toast("Échec de l'enregistrement : ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val pending = pendingDownload
            pendingDownload = null
            if (granted && pending != null) {
                writeDownload(pending.first, pending.second)
            } else {
                toast("Permission refusée — enregistrement annulé")
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
